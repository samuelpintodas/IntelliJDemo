
public class bitsTab {
	
	static int[] tab;

	public static void main(String[] args) 
	{	
		bitsTab bTab = new bitsTab(3);
		
		bTab.generateBitsTab();
	}
	
	public bitsTab(int i)
	{		
		tab = new int[i];
		
		for(int j = 0; tab.length<i; i++)
			tab[j] = 0;
		
	}
	
	public void generateBitsTab()
	{
		generateBitsTab(tab.length-1);
	}

	private static void generateBitsTab(int index) 
	{
			
		
		
		int startIndex = tab.length-1;
		
		if(index == 0)
			return;
		
//		tab[index]+=1;
		
		if(tab[startIndex] == 1){
			printTab();
			index-=1;
			exchange(index,startIndex);
			tab[index+1] = 0;
			System.out.println("passage A");
		
			
		}
		if(tab[startIndex] == 0){
			printTab();
			tab[startIndex]+=1;
			System.out.println("passage B");
			generateBitsTab(index);
			
			
		}
		
		
	}


	
	private static void exchange(int a, int b)
	{
		int temp;
		
		temp = tab[a];
		tab[a] = tab[b];
		tab[b] = temp;
	}
	
	private static void printTab()
	{
		System.out.print("[");
		for(int l = 0; l<tab.length; l++)
			System.out.print(tab[l] + " ");
		
		System.out.print("]\n");
			
	}
	
}

	

