import java.util.Scanner;

public class Ex2 {
	
	static int number;
	static String stringNumber="";

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner input = new Scanner(System.in);
		
		System.out.println("Ins�rez un entier");
		number = input.nextInt();
		
		System.out.println("Entier converti:");
		System.out.println(convertToString(stringNumber,number));
		
		
	}

	private static String convertToString(String stnum, int num) {
		
		// Clause de finitude
		if(num==0)
			return stringNumber;
		
		
		//pas r�cursif
		return convertToString(stringNumber=(num%10)+stnum, num/10);
	}

}
