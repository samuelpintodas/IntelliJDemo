import java.util.Scanner;

public class Ex1 {
	
	static int entier;
	static String stringEntier;
	static int cptZero = 0;
	static int index = 0;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	Scanner input = new Scanner(System.in);
	
	System.out.println("Definissez un entier");
	entier = input.nextInt();
	
	stringEntier = Integer.toString(entier);
		
	System.out.println("Nombres de 0 : " + countZero(index));
	
	}

	private static int countZero(int index) {
		// TODO Auto-generated method stub
		
		//clause de finitude
		if(index == stringEntier.length())
			return cptZero;
		
		if(entier == 0)
			return 1;
		
		char charac = stringEntier.charAt(index);
		
		if(charac == '0'){
			cptZero+=1;
			index+=1;
			return countZero(index);
		}
		
		index+=1;
		return countZero(index);
	}
	

}
