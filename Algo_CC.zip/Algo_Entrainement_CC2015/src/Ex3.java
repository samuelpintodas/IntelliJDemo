
public class Ex3 {
	
	static int[][] tab = {	{1, 3, 4, 5},
							{3, 9, 6, 2},
							{1, 2, 4, 1},
							{7, 3, 4, 3}};

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		affiche(tab);
		triBullesVersionMatricePutain(1);
		affiche(tab);
		
		
	}
	
	public static void triBullesVersionMatricePutain(int index) {
		System.out.println("Apr�s triBulles");

		int tabSize = tab[0].length;
		boolean tabInOrder = false;
		int temp;

		while (!tabInOrder) {
	
			tabInOrder = true;
			for (int i = 0; i < tabSize-1; i++) {

				if (tab[index][i] > tab[index][i + 1]) {

					inverse(i, i+1);
					tabInOrder = false;

				}

			}

			tabSize--;
		}

	}
	
	private static void inverse(int a, int b){		
		
		int [] temp;
		
		temp = tab[a];
		tab[a] = tab[b];
		tab[b] = temp;
				
	}
	
	private static void printTab(int [] tab)
	{
		System.out.print("[");
		for(int l = 0; l<tab.length; l++)
			System.out.print(tab[l] + " ");
		
		System.out.print("]\n");
			
	}
	
	public static void affiche(int[][] matrice) {
		for(int i=0; i<matrice.length; i++) {
			for (int j=0; j<matrice.length; j++) {
				System.out.print(matrice[i][j]+"\t");
			}
			System.out.println();
		}
	}

}
